// Package graphviz provides some simple types for building graphviz DOT files
// based on their usage for container debugging. It does not attempt to cover
// all of graphviz, just what is needed here.
package graphviz
