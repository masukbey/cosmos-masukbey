---
sidebar_position: 1
---

# Overview of `app.go`

This section is intended to provide an overview of the `SimApp` `app.go` file and is still a work in progress.
For now please instead read the [tutorials](https://tutorials.cosmos.network) for a deep dive on how to build a chain.

## Complete `app.go`

```go reference
https://github.com/cosmos/cosmos-sdk/blob/v0.50.0-alpha.0/simapp/app.go
```
