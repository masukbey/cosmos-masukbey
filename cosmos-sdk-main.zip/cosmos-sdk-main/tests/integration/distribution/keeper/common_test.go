package keeper_test

import (
	simtestutil "github.com/cosmos/cosmos-sdk/testutil/sims"
)

var (
	PKS = simtestutil.CreateTestPubKeys(3)

	valConsPk0 = PKS[0]
)
